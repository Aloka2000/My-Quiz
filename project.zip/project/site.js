
let questions = [
  {
    id: 1,
    question: "what is largest river in the world?",
    answer: "Amazon river",
    options: [
      "Amazon river",
      "Nile river",
      "Mekong river",
      "Mississippi river"
    ]
  },


  {
    id: 2,
    question: "what is the tallest buliding in the world ",
    answer: "Burj khalifa-dubai",
    options: [
      "Shanghai tower- china",
      "Burj khalifa-dubai",
      "Empire State Building-new york",
      "Lotte world tower-seoul"
    ]
  },


  {
    id: 3,
    question: "second world war started in?",
    answer: "september 1, 1939",
    options: [
      "May 6, 1940",
      "Januvary 5, 1945",
      "June 4, 1868",
      "september 1, 1939"
    ]
  },


  {
    id: 4,
    question: "who were the founders of Apple inc?",
    answer: "Steve jobs, Steve wozniak, Ronald wayne",
    options: [
      "Larry Page, Sergey Brinm Sundar Punchi",
      "Andrea Ghez, Reinhard Genzel , Roger Penrose",
      "Steve jobs, Steve wozniak, Ronald wayne",
      "Richrad Nixon,Gerald ford, John F Kenndy"
    ]
  },

  {
    id: 5,
    question: "where is silicon valley located?",
    answer: "San Franciso- California",
    options: [
      "San Franciso- California",
      "Detroit-Michigan",
      "New york city- New york",
      "Seattle-Washington"
    ]
  },


  {
    id: 6,
    question: "The most populous city in the world?",
    answer: "Tokyo-Japan",
    options: [
      "Tokyo-Japan",
      "New delhi- India",
      "Stockholm- Sweden",
      "London-uk"
    ]
  },

  {
    id: 7,
    question: "How many states are there in india?",
    answer: "29",
    options: [
      "30",
      "29",
      "50",
      "40"
    ]
  },


  {
    id: 8,
    question: "when was the Magna carta signed?",
    answer: "1215, June 15",
    options: [
      "1668, Januvary 1",
      "1776, July 4",
      "1215, June 15",
      "1458, June 30"
    ]
  },


  {
    id: 9,
    question: "who discovered the electron?",
    answer: "J.J thompson",
    options: [
      "Enarest rutherford",
      "James Chadwick",
      "J.J thompson",
      "john dalton"
    ]
  },

  {
    id: 10,
    question: "who discover the telephone?",
    answer: "Alexander Graham bell",
    options: [
      "Kenjiro Takayanagi",
      "Philo Farnsworthk",
      "John Logie Baird",
      "Alexander Graham bell"
    ]
  },

  {
    id: 11,
    question: "For what discovery einstein won the noble prize",
    answer: "law of photoeletic effect",
    options: [
      "General relativly",
      "Special relativly",
      "discovery of uranium",
      "law of photoeletic effect"
    ]
  },

  {
    id: 12,
    question: "who were the mother-daughter ever to win the noble prize?",
    answer: "Marie curie and Irene joliot curie",
    options: [
      "Marie curie and Irene joliot curie",
      "Marie curie and Pierre Curie ",
      "Gerty Cori and Carl Cori",
      "William Bragg and Lawrence Bragg"
    ]
  },


  {
    id: 13,
    question: "what doest FBI stands for ?",
    answer: "Federal bureau of investication",
    options: [
      "Federal board of investication ",
      "Federal bureau of inspecter",
      "Federal bureau of investication",
      "Federation of investication"
    ]
  },

  {
    id: 14,
    question: "what does KFC stands for ?",
    answer: "kentuky Fried chicken",
    options: [
      "kispy fried chiken",
      "kichten food corner",
      "kentuky Fried chicken",
      "kansas fried chicken"
    ]
  },

  {
    id: 15,
    question: "The first secretary of state of USA?",
    answer: "Thomas jefferson",
    options: [
      "John Adams",
      "Thomas jefferson",
      "Alexander Hamilton",
      "George Washington"
    ]
  },

  {
    id: 16,
    question: "who is the father of computering?",
    answer: "Charles Babbage",
    options: [
      "Alan turning",
      "Charles Babbage",
      "joseph fourier",
      "Blaise Pascal"
    ]
  },

  {
    id: 17,
    question: "who invented World wide web?",
    answer: "Tim Berners Lee",
    options: [
      "Theodore roosevelt",
      "Tim Berners Lee",
      "willam cook",
      "Steve Jobs"
    ]
  },

  {
    id: 18,
    question: "First computer programmer?",
    answer: "Ada lovelace",
    options: [
      "Ada lovelace",
      "Robert Oppenheimer",
      "Edward teller",
      "Alan turning"
    ]
  },

  {
    id: 19,
    question: "who pianted mona Lisa?",
    answer: "Leonardo da vinci",
    options: [
      "Leonardo da vinci",
      "Michelangelo",
      "Vincent van gogh",
      "Pablo picasso"
    ]
  },


  {
    id: 20,
    question: "The country of origin of the current Pope of the holy see?",
    answer: "Argentina",
    options: [
      "Brazil",
      "Peru",
      "Argentina",
      "Germany"
    ]
  },
];

let question_count = 0;
let points = 0;

window.onload = function() {
  show(question_count);

};

function next() {

   
  // if the question is last then redirect to final page
  if (question_count == questions.length - 1) {
    sessionStorage.setItem("time", time);
    clearInterval(mytime);
    location.href = "end.html";
  }
  console.log(question_count);

  let user_answer = document.querySelector("li.option.active").innerHTML;
  // check if the answer is right or wrong
  if (user_answer == questions[question_count].answer) {
    points += 1;
    sessionStorage.setItem("points", points);
  }
  console.log(points);

  question_count++;
  show(question_count);
}

function show(count) {
  let question = document.getElementById("questions");
  let [first, second, third, fourth] = questions[count].options;

  question.innerHTML = `
  <h2>Q${count + 1}. ${questions[count].question}</h2>
   <ul class="option_group">
  <li class="option">${first}</li>
  <li class="option">${second}</li>
  <li class="option">${third}</li>
  <li class="option">${fourth}</li>
</ul> 
  `;
  toggleActive();
}

function toggleActive() {
  let option = document.querySelectorAll("li.option");
  for (let i = 0; i < option.length; i++) {
    option[i].onclick = function() {
      for (let i = 0; i < option.length; i++) {
        if (option[i].classList.contains("active")) {
          option[i].classList.remove("active");
        }
      }
      option[i].classList.add("active");
    };
  }
}
